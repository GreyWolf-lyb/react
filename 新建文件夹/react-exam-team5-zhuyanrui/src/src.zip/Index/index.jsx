import React, { Component } from 'react';
import Topic from "./page/Topic/index.jsx"
import {Route} from "dva/router"

class Index extends Component {
    render() {
        return (
            <div className="warp">
                <header></header>
                 <section>
                 <Route path="/topic" component={Topic} />
                 </section>
            </div>
        );
    }
}

export default Index;